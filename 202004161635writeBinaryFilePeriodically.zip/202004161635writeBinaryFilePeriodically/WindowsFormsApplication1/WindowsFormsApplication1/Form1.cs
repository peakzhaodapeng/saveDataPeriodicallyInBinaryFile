﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Load(@"C:\Users\Administrator\Desktop\myCodeLibrary\202004161635writeBinaryFilePeriodically\red.jpg");

        }
        bool flag=true;

       // string filename = @"C:\Program Files\binary.China";//后缀可以任意设置
           
        private void button1_Click(object sender, EventArgs e)
        {

            if (flag)
            {
                timer1.Enabled = true;
               

                pictureBox1.Load(@"C:\Users\Administrator\Desktop\myCodeLibrary\202004161635writeBinaryFilePeriodically\green.jpg");
                label1.Text = "writing";

            }
            else
            {
                timer1.Enabled = false;

                //writer.Close();
                //fs.Close();

                pictureBox1.Load(@"C:\Users\Administrator\Desktop\myCodeLibrary\202004161635writeBinaryFilePeriodically\red.jpg");
                label1.Text = "stop writing";
            }
                flag = !flag;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string filename = @"C:\Program Files\binary.China";
            //textBox1.Text += "a5";  
            FileStream fs = new FileStream(filename, FileMode.Append);
            BinaryWriter writer = new BinaryWriter(fs);
            writer.Write((byte)0x01);
            writer.Write((byte)0x02);
            writer.Write((byte)0x03);
            writer.Write((byte)0x04);
            writer.Write((byte)0x05);
            writer.Close();
            fs.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string filename = @"C:\Program Files\binary.China";
            if (!(File.Exists(filename)))
            {
                MessageBox.Show("current file not exists");
                return;
            }
            string strData = "";
            FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read);
            BinaryReader reader = new BinaryReader(fs);
            try
            {
               // strData = reader.ReadByte().ToString();
                while (true)
                {
                   // strData += "||" + reader.ReadInt32().ToString();
                   // strData +=reader.ReadInt32().ToString();
                    strData += reader.ReadByte().ToString();
                }
            }
            catch (EndOfStreamException es)
            {

            }
            textBox1.Text = strData;
            fs.Close();
            reader.Close();
        }
    }
}
